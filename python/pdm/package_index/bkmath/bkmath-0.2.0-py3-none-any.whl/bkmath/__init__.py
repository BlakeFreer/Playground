import numpy as np

print("In BkMath")


def add(x, y):
    return np.add(x, y)


def multiply(x, y):
    return np.multiply(x, y)
