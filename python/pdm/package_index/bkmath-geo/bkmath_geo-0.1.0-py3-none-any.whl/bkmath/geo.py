import numpy as np

import bkmath

print("In bkmath.geo")


def area(radius):
    return bkmath.multiply(radius, radius) * np.pi
